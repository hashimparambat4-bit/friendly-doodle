HASHIM Nursing offline-first web + Android project

Brand: HASHIM Nursing | Learn. Practice. Lead.
Themes: Complete Black, Lavender + Dark Charcoal, Ocean Glow.
Navigation: separate sections, bottom/section navigation and horizontal swipe gestures on mobile.
Data: local device storage; no AI and no cloud sync.

Android APK is built by GitHub Actions from .github/workflows/build-apk.yml. Upload this project to a GitHub repository and run the workflow. The ZIP is a source project, not a compiled APK.
