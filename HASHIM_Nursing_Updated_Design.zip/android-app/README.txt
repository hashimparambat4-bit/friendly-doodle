RAILPREP NURSING — ANDROID STUDIO PROJECT


BUILD APK IN ANDROID STUDIO
1. Open this android-app folder in Android Studio.
2. Use JDK 17 and allow Gradle/Android Gradle Plugin dependencies to download.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.

BUILD FROM AN ANDROID PHONE
1. Upload the extracted package contents to a GitHub repository (keep .github/workflows/build-apk.yml at the repository root and android-app/ at the root).
2. Open GitHub Actions, choose “Build RailPrep Nursing APK”, and run the workflow.
3. When complete, download the workflow artifact named railprep-nursing-debug-apk.

The current download contains the project source and build workflow, not a precompiled APK. No cloud sync is included.

AI REMOVED: This build contains no AI tutor, Gemini integration, API-key settings, or AI network requests. Notes, practice, revision and local backup work without AI.

MCQ options update: answer choices are filtered by answer type and similar format. Questions without three compatible distractors are skipped instead of being padded with unrelated options. Because source notes are one-line facts, review the source entry for accuracy.


Latest design refresh: Clinical Teal default theme with a clean white surface, teal highlights, navy typography, refreshed cards and Android system-bar colours. Other appearance choices remain available in Settings.
