HASHIM Nursing offline-first web + Android project

Brand: HASHIM Nursing | Learn. Practice. Lead.
Themes: Complete Black, Lavender + Dark Charcoal, Ocean Glow.
Navigation: separate sections, bottom/section navigation and horizontal swipe gestures on mobile.
Data: local device storage; no AI and no cloud sync.

Android APK is built by GitHub Actions from .github/workflows/build-apk.yml. Upload this project to a GitHub repository and run the workflow. The ZIP is a source project, not a compiled APK.

UPDATED PROJECT NOTES
- Added source-derived General Awareness questions from the supplied RRB General Knowledge PDF.
- Added source-derived Mathematics & General Arithmetic questions with options, answers and worked explanations from the supplied arithmetic PDF.
- Preserved existing nursing notes and local progress features.
- Android-only: added a home-screen quick flashcard widget and a daily reminder notification (around 7 PM, subject to Android scheduling/notification permission).
- Widget cards are currently a small built-in nursing set and do not yet sync to the full notes library. Notifications are local reminders, not remote push notifications.
- Rebuild the Android APK from android-app/ using Android Studio (JDK 17). This ZIP is source code; an APK was not built or tested in this environment.
- Note: The mathematics PDF cover says 520 MCQs, while the extraction detected 600 question blocks; review the imported mathematics section against the PDF before relying on the count.


Flashcard widget connection: The Android widget is now backed by the full app notes dataset (android-app/app/src/main/assets/flashcards.json), rather than the six hard-coded demo cards. The dataset includes all non-empty note entries exported from RAILPREP_NOTES. Rebuild and reinstall the app to apply the code change.
