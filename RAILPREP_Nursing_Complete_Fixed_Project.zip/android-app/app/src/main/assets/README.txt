RAILPREP NURSING — WEBSITE / PWA

Files: index.html, app.js, advanced.js, app-data.js, sw.js, manifest.webmanifest, icon.svg.
Keep these files together in the website root.

Open index.html to use the notes library and offline study tools. For installable PWA caching, deploy this folder to HTTPS and open it once.


Quiz data note: MCQ prompts and correct answers are parsed from source PDF entries containing a question mark and trailing answer. Distractors are automatically assembled from other source answers; some may be ambiguous. Every item shows the source entry. These are not professionally validated questions.


No account, cloud sync or server backend is included. Study progress remains on this browser/device unless you manually export/import a backup.

AI REMOVED: This build contains no AI tutor, Gemini integration, API-key settings, or AI network requests. Notes, practice, revision and local backup work without AI.
