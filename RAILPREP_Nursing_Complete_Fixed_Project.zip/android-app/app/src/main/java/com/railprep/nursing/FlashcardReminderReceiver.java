package com.railprep.nursing;
import android.app.*;
import android.content.*;
import android.os.Build;

public class FlashcardReminderReceiver extends BroadcastReceiver {
  public static void schedule(Context c) {
    AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
    Intent i=new Intent(c,FlashcardReminderReceiver.class);
    PendingIntent pi=PendingIntent.getBroadcast(c,77,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    java.util.Calendar cal=java.util.Calendar.getInstance(); cal.setTimeInMillis(System.currentTimeMillis()); cal.set(java.util.Calendar.HOUR_OF_DAY,19); cal.set(java.util.Calendar.MINUTE,0); cal.set(java.util.Calendar.SECOND,0); if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_YEAR,1);
    if(am!=null) am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
  }
  @Override public void onReceive(Context c,Intent i) {
    if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) return;
    String channel="flashcard_daily";
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(channel,"Daily flashcard reminder",NotificationManager.IMPORTANCE_DEFAULT));
    Intent open=new Intent(c,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(c,78,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
    nm.notify(78,b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("RailPrep Nursing · Flashcard time").setContentText("Take 5 minutes to revise a nursing flashcard today.").setContentIntent(pi).setAutoCancel(true).build());
  }
}
